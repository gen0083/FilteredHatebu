package jp.gcreate.product.filteredhatebu.util;

/**
 * Copyright 2016 G-CREATE
 */

public class StethoWrapper {
    public void install(){
        // no-op
    }
}
