package jp.gcreate.product.filteredhatebu

import org.junit.Test
import org.koin.test.KoinTest
import org.koin.test.dryRun

class KoinModuleTest : KoinTest {
    @Test fun koin_module_test() {
        dryRun()
    }
}
