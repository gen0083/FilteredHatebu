package jp.gcreate.product.filteredhatebu.ui.common

enum class LoadingState {LOADING, DONE}