package jp.gcreate.product.filteredhatebu.util

import android.content.Context

/**
 * Copyright 2018 G-CREATE
 */
class CrashlyticsWrapper {
    fun init(context: Context) {
        // do-nothing
    }
}
