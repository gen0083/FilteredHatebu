
from __future__ import with_statement
from fabric.operations import *
from fabric.api import *
from fabric.decorators import task
import time

gsurl = 'gs://cyborg-build-archiherewego-gmail-com/jp.gcreate.product.filteredhatebu'
build_token = '1482310955943c9888d925be193bc545105b9a4ef5257'
package_name = 'jp.gcreate.product.filteredhatebu'

def sync():
    tmp_dir = "/tmp/" + package_name
    local("mkdir -p " + tmp_dir)
    with open(".gitignore", "r") as f:
        excludes = [line.replace("\n", "") for line in f if not re.match(r"[#\n]", line)]
        ignore_file = "local.properties"  # must exclude
        if ignore_file not in excludes:
            excludes.append(ignore_file)
    excludes.append(".git")
    excludes.append("build")
    rsync = "rsync -aR --delete " + " ".join(map(lambda exclude: "--exclude '" + exclude + "'", excludes)) + " . " + tmp_dir
    local(rsync)

    command = "gsutil -m rsync -e -x \"local.properties|fabfile.py|fabfile.pyc\" -d -r " + tmp_dir + " " + gsurl
    local(command)

# tasks
@task
def cleanSync():
    start = time.time()
    sync()
    local("curl http://cyborg-build.com/v1/clean_sync/" + build_token)
    elapsed_time = time.time() - start
    print ("Task Finished:%.1f" % elapsed_time) + "[sec]"

@task
def clean():
    start = time.time()
    sync()
    artifact = ''
    suffix = ''
    activity = ''

    local("curl http://cyborg-build.com/v1/build/" + build_token + "/clean")
    if artifact:
        local("gsutil cp " + gsurl + "/" + artifact + " " + artifact)

    # launch
    if activity:
        local("adb install -r " + artifact)
        package_name_with_suffix = package_name
        if suffix:
            package_name_with_suffix = package_name + "." + suffix
        local("adb shell am start -n '" + package_name_with_suffix + "/" + package_name + "." + activity + "' -a android.intent.action.MAIN -c android.intent.category.LAUNCHER")

    elapsed_time = time.time() - start
    print ("\n\n---------------------------------")
    print ("Task Finished:%.1f" % elapsed_time) + "[sec]"
    if artifact:
      print ("build artifact: " + artifact)
    print ("---------------------------------")


@task
def assembleDebug():
    start = time.time()
    sync()
    artifact = 'app/build/outputs/apk/app-debug.apk'
    suffix = ''
    activity = ''

    local("curl http://cyborg-build.com/v1/build/" + build_token + "/assembleDebug")
    if artifact:
        local("gsutil cp " + gsurl + "/" + artifact + " " + artifact)

    # launch
    if activity:
        local("adb install -r " + artifact)
        package_name_with_suffix = package_name
        if suffix:
            package_name_with_suffix = package_name + "." + suffix
        local("adb shell am start -n '" + package_name_with_suffix + "/" + package_name + "." + activity + "' -a android.intent.action.MAIN -c android.intent.category.LAUNCHER")

    elapsed_time = time.time() - start
    print ("\n\n---------------------------------")
    print ("Task Finished:%.1f" % elapsed_time) + "[sec]"
    if artifact:
      print ("build artifact: " + artifact)
    print ("---------------------------------")


@task
def assembleProdDebug():
    start = time.time()
    sync()
    artifact = 'app/build/outputs/apk/app-prod-debug.apk'
    suffix = 'debug'
    activity = 'ui.feedlist.HatebuFeedActivity'

    local("curl http://cyborg-build.com/v1/build/" + build_token + "/assembleProdDebug")
    if artifact:
        local("gsutil cp " + gsurl + "/" + artifact + " " + artifact)

    # launch
    if activity:
        local("adb install -r " + artifact)
        package_name_with_suffix = package_name
        if suffix:
            package_name_with_suffix = package_name + "." + suffix
        local("adb shell am start -n '" + package_name_with_suffix + "/" + package_name + "." + activity + "' -a android.intent.action.MAIN -c android.intent.category.LAUNCHER")

    elapsed_time = time.time() - start
    print ("\n\n---------------------------------")
    print ("Task Finished:%.1f" % elapsed_time) + "[sec]"
    if artifact:
      print ("build artifact: " + artifact)
    print ("---------------------------------")

